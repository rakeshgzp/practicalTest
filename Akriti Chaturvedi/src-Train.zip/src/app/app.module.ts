import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';

import {RouterModule, Routes} from '@angular/router';

import { FormsModule } from '@angular/forms';
import { FilterPipe } from './filter.pipe';

import {TrainComponent} from './train/train.component';
import {PassComponent} from './pass/pass.component';
import {HomeComponent} from './home/home.component';

import {TraininformationService} from './traininformation.service';


const appRoutes : Routes = [
  {
    path: 'Train',
   component: TrainComponent
  },
  {
    path: 'Pass',
   component: PassComponent
  },
  {
    path: 'Home',
    component: HomeComponent
  },
  {
    path: '',
    redirectTo: 'Home',
    pathMatch: "full"
    }];

@NgModule({
  declarations: [
    AppComponent,
    PassComponent,
    TrainComponent,
    HomeComponent,
    FilterPipe
    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    RouterModule.forRoot(appRoutes) ,
    FormsModule
  ],
  providers: [TraininformationService],
  bootstrap: [AppComponent],
  exports: [RouterModule]
})
export class AppModule { }
