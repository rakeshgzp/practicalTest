import { Injectable } from '@angular/core';
import { Passenger } from './passenger-info';

@Injectable({
  providedIn: 'root'
})
export class PassInfoService {

  constructor() { }
  pass : Passenger[] = [
    {
      id: '1',
      name: 'Akriti',
      age: '23',
      gender: 'F',
      contact: '987665432',
    },
    {
      id: '2',
      name: 'Ashray',
      age: '23',
      gender: 'M',
      contact: '987665432',
    },
    {
      id: '3',
      name: 'Avni',
      age: '23',
      gender: 'F',
      contact: '987665432',
    },
    {
      id: '4',
      name: 'Will',
      age: '23',
      gender: 'M',
      contact: '987665432',
    },
    {
      id: '5',
      name: 'Cary',
      age: '23',
      gender: 'M',
      contact: '987665432',
    },
    {
      id: '6',
      name: 'Diane',
      age: '23',
      gender: 'F',
      contact: '987665432',
    }
  ] 
}
