export class Passenger{
    id:String;
    name:String;
    age:String;
    gender:String;
    contact:String;
    constructor(id:String,
        name:String,
        age:String,
        gender:String,
        contact:String){
            this.id=id;
            this.name=name;
            this.age=age;
            this.gender=gender;
            this.contact=contact;
        }

}