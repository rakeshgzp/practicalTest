import { Component, OnInit } from '@angular/core';
import { PassInfoService } from '../pass-info.service';
@Component({
  selector: 'app-pass',
  templateUrl: './pass.component.html',
  styleUrls: ['./pass.component.css']
})
export class PassComponent implements OnInit {

  constructor(private pass:PassInfoService) { }

  use:any[];
  no:String='';
  ngOnInit(): void {
    this.use=this.pass.pass;
    console.log(this.no);
  }

}
