package com.example.controller;

import com.example.*;
import com.example.dao.*;
import com.example.exception.*;
import com.example.repo.EmployeeRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
//import javax.validation.Valid;
import java.util.List;

@RestController
@RequestMapping("/api")
@CrossOrigin
public class Controller {

    @Autowired
    EmployeeRepository empRepo;
    
    @GetMapping("/emp")
    public List<Employee> getAllNotes() {
        return empRepo.findAll();
    }
    
    @PostMapping("/saveemp")
    public Employee createEmp(@RequestBody Employee emp) {
        return empRepo.save(emp);
    }
    
    @GetMapping("/emp/{id}")
    public Employee getEmpById(@PathVariable(value = "id") Long id) {
        return empRepo.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Employee", "id", id));
    }
    
    
    @PutMapping("/emp/{id}")
    public Employee updateEmp(@PathVariable(value = "id") Long id, @RequestBody Employee emp) {

        Employee e = empRepo.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Employee", "id", id));

        e.setId(emp.getId());
        e.setFirstname(emp.getFirstname());
        e.setLastname(emp.getLastname());
        e.setDesig(emp.getDesig());
        e.setDept(emp.getDept());
        e.setSal(emp.getSal());

        Employee updatedemp = empRepo.save(e);
        return updatedemp;
    }
    
    @DeleteMapping("/emp/{id}")
    public ResponseEntity<?> deleteEmployee(@PathVariable(value = "id") Long id) {
        Employee emp = empRepo.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Employee", "id", id));

        empRepo.delete(emp);

        return ResponseEntity.ok().build();
    }
}