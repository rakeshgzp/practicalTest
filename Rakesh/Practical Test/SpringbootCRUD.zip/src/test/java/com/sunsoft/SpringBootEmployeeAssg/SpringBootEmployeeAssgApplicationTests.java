package com.sunsoft.SpringBootEmployeeAssg;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootEmployeeAssgApplicationTests {

	@Test
	void contextLoads() {
	}

}
