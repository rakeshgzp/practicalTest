package com.sunsoft.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import com.sunsoft.dao.EmployeeDao;
import com.sunsoft.model.EmployeeData;

@RestController
public class EmployeeController {

	@Autowired
	EmployeeDao studentDao;
	@RequestMapping ("/insert")
	public String insertData() {
		EmployeeData studentObj = new EmployeeData();
		studentObj.setId(11);
		studentObj.setName("Rakesh");
		studentObj.setSalary(80000);
		studentObj.setDept("CSE");
		
		EmployeeData studentObj2 = new EmployeeData();
		studentObj2.setId(21);
		studentObj2.setName("Abhinav");
		studentObj2.setSalary(90000);
		studentObj2.setDept("IT");
		
		studentDao.insertData(studentObj);
		studentDao.insertData(studentObj2);
		return "Data inserted Successfully";
	}
	
	@RequestMapping ("/delete/{id}")
	public String deleteData(@PathVariable ("id") int id)
	{
		studentDao.deleteRecord(id);
		return "Record deleted successfully";
	}
	
	@RequestMapping ("/update")
	public String updateData(@RequestParam("id") int id, @RequestParam("name") String name, @RequestParam("dept") String dept, @RequestParam("salary")int salary) {
		EmployeeData obj = new EmployeeData();
	obj.setId(id);
	obj.setName(name);
	obj.setSalary(salary);
	obj.setDept(dept);
	studentDao.updateData(obj);
		return "Data updated successfully";
	}
	
	@RequestMapping ("/displayAll")
	public List<EmployeeData> displayData() {
		List<EmployeeData> studentList = studentDao.displayAll();
		return studentList;
	}
}
