package com.sunsoft.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sunsoft.model.EmployeeData;
import com.sunsoft.repository.EmployeeRepository;

@Service
public class EmployeeDao {

	@Autowired
	EmployeeRepository studentRepository;
	public void insertData(EmployeeData studentObj) {
		studentRepository.save(studentObj);
	}
	public void deleteRecord(int id) {
		studentRepository.deleteById(id);
	}
	public List<EmployeeData> displayAll() {
		List<EmployeeData> studentList = (List<EmployeeData>) studentRepository.findAll(); 
		return studentList;
	}
	public void updateData(EmployeeData studentObj) {
		
		studentRepository.save(studentObj);
	}
}
