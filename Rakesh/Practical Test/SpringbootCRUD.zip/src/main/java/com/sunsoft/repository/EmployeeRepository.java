package com.sunsoft.repository;

import org.springframework.data.repository.CrudRepository;

import com.sunsoft.model.EmployeeData;


public interface EmployeeRepository extends CrudRepository<EmployeeData, Integer> {

}
